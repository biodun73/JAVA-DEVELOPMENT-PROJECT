
package mainframe;


public class MainFrame {

    public static void main(String[] args) {
        CBabyBallBounce frame = new CBabyBallBounce();
        frame.setSize(825, 585);
        frame.setVisible(true);  
    }
      
}

